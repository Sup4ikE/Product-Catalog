﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Product_Catalog
{
    public partial class Form2 : Form
    {
        Item product = null; 
        bool isAddOrEdit;

        public Form2()
        {
            InitializeComponent();
        }
        public Form2(Item product, bool isAddOrEdit)
        {
            InitializeComponent(); 
            this.product = product;
            this.isAddOrEdit = isAddOrEdit;
            if (!isAddOrEdit)
            {
                textBox1.Text = product.Name; 
                textBox2.Text = product.Country;
                textBox3.Text = product.Price.ToString(); 
                Text = "Edit Product";
            }
            else
            {
                Text = "Add Product";
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            product.Name = textBox1.Text;
            product.Country = textBox2.Text; 
            product.Price = int.Parse(textBox3.Text);
            DialogResult = DialogResult.OK;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}
