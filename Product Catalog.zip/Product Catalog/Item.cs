﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Product_Catalog
{
    public class Item
    {
        public string Name { get; set; }
        public string Country { get; set; }
        public int Price { get; set; }
        public Item()
        {
            Name = "";
            Country = ""; 
            Price = 0;
        }
        public Item(string name, string country, int price)
        {
            Name = name;
            Country = country; Price = price;
        }
        public override string ToString() { return Name + " | " + Country + " | " + Price; }
    }
}
