using System.Windows.Forms;

namespace Product_Catalog
{
    public partial class Form1 : Form
    {
        Item product = null;
        public Form1()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            product = new Item();
            Form2 addForm = new Form2(product, true);
            if (addForm.ShowDialog() == DialogResult.OK)
            {
                listBox1.Items.Add(product);
            }
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            product = (Item)listBox1.SelectedItem;
            Form2 editForm = new Form2(product, false);
            if (editForm.ShowDialog() == DialogResult.OK)
            {
                listBox1.Items[listBox1.SelectedIndex] = product;
            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            for (int i = listBox1.SelectedIndices.Count - 1; i >= 0; i--)
            {
                listBox1.Items.RemoveAt(listBox1.SelectedIndices[i]);
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
        }
    }
}